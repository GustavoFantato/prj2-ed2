#include "functions.h"
#include "utils.h"

void deleteFromTable(char *arquivoDados, char *arquivoIndex, int n) {
    
    FILE *binFile = fopen(arquivoDados, "rb+");
    if (binFile == NULL) {
        printf("Falha no processamento do arquivo.\n");
        return;
    }

    // Lê cabeçalho COMPLETO
    HeaderRecord header;
    fread(&header.status, sizeof(char), 1, binFile);
    if (header.status == '0') {
        printf("Falha no processamento do arquivo.\n");
        fclose(binFile);
        return;
    }
    fread(&header.topo, sizeof(int), 1, binFile);
    fread(&header.proxRRN, sizeof(int), 1, binFile);
    fread(&header.nroEstacoes, sizeof(int), 1, binFile);
    fread(&header.nroParesEstacao, sizeof(int), 1, binFile);

    FILE *indexFile = fopen(arquivoIndex, "rb");
    if (indexFile == NULL) {
        printf("Falha no processamento do arquivo.\n");
        fclose(binFile);
        return;
    }

    char indexStatus;
    fread(&indexStatus, sizeof(char), 1, indexFile);
    if (indexStatus == '0') {
        printf("Falha no processamento do arquivo.\n");
        fclose(binFile);
        fclose(indexFile);
        return;
    }

    header.status = '0';
    fseek(binFile, 0, SEEK_SET);
    fwrite(&header.status, sizeof(char), 1, binFile);

    fseek(indexFile, INDEX_HEADER_SIZE, SEEK_SET);
    IndexRecord *indexList = NULL;
    int qtdIndex = 0;
    IndexRecord tempIdx;
    
    while (fread(&tempIdx.codEstacao, sizeof(int), 1, indexFile) == 1) {
        fread(&tempIdx.RRN, sizeof(int), 1, indexFile);
        qtdIndex++;
        indexList = realloc(indexList, qtdIndex * sizeof(IndexRecord));
        indexList[qtdIndex - 1] = tempIdx;
    }
    fclose(indexFile);

    for (int i = 0; i < n; i++) {
        
        int m;
        scanf("%d", &m); 

        char campos[8][30];
        char valores[8][100];
        
        int useIndexFile = 0;
        int indiceCodEst = -1;

        for (int j = 0; j < m; j++) {
            scanf("%s", campos[j]); 
            if (strcmp(campos[j], "codEstacao") == 0) {
                useIndexFile = 1;
                indiceCodEst = j;
            }     
            if (strcmp(campos[j], "nomeEstacao") == 0 || strcmp(campos[j], "nomeLinha") == 0) {
                ScanQuoteString(valores[j]); 
            } else { 
                scanf("%s", valores[j]);
                if (strcmp(valores[j], "NULO") == 0) {
                    strcpy(valores[j], "");
                }
            }
        }

        if (useIndexFile) {
            int codBusca = atoi(valores[indiceCodEst]);
            int targetRRN = -1;
            
            for (int idx = 0; idx < qtdIndex; idx++) {
                if (indexList[idx].codEstacao == codBusca) {
                    targetRRN = indexList[idx].RRN;
                    break;
                }
            }

            if (targetRRN != -1) {
                long offset = DATA_HEADER_SIZE + ((long)targetRRN * DATA_REGISTER_SIZE);
                fseek(binFile, offset, SEEK_SET);
                
                char removed;
                fread(&removed, sizeof(char), 1, binFile);
                
                if (removed == '0') {
                    DataRecord data;
                    data.removido = removed;
                    lerRegistro(&data, binFile);
                    
                    int match = 1;
                    for (int f = 0; f < m; f++) {
                        checkMatch(data, campos, f, valores, &match);
                        if (!match) break;
                    }

                    if (match) {
                        // Atualiza nroEstacoes: verifica se é o último com esse nome
                        int nomeExiste = verifyName(binFile, data.nomeEstacao, offset);
                        if (!nomeExiste && header.nroEstacoes > 0) header.nroEstacoes--;

                        // Atualiza nroParesEstacao
                        if (data.codProxEstacao != -1 && header.nroParesEstacao > 0) header.nroParesEstacao--;

                        fseek(binFile, offset, SEEK_SET);
                        char mark = '1';
                        fwrite(&mark, sizeof(char), 1, binFile);
                        fwrite(&header.topo, sizeof(int), 1, binFile);
                        header.topo = targetRRN;

                        for (int idx = 0; idx < qtdIndex; idx++) {
                            if (indexList[idx].codEstacao == codBusca) {
                                for (int k = idx; k < qtdIndex - 1; k++) {
                                    indexList[k] = indexList[k + 1];
                                }
                                qtdIndex--;
                                break;
                            }
                        }
                    }
                    if (data.nomeEstacao != NULL) free(data.nomeEstacao);
                    if (data.nomeLinha != NULL) free(data.nomeLinha);
                }
            }
        } 
        else { 
            for (int rrnAtual = 0; rrnAtual < header.proxRRN; rrnAtual++) {
                long offset = DATA_HEADER_SIZE + ((long)rrnAtual * DATA_REGISTER_SIZE);
                fseek(binFile, offset, SEEK_SET);

                char removed;
                fread(&removed, sizeof(char), 1, binFile);

                if (removed == '1') continue;

                DataRecord data;
                data.removido = removed;
                lerRegistro(&data, binFile);

                int match = 1; 
                for (int f = 0; f < m; f++) {
                    checkMatch(data, campos, f, valores, &match);
                    if (!match) break;
                }

                if (match) {
                    int nomeExiste = verifyName(binFile, data.nomeEstacao, offset);
                    if (!nomeExiste && header.nroEstacoes > 0) header.nroEstacoes--;
                    if (data.codProxEstacao != -1 && header.nroParesEstacao > 0) header.nroParesEstacao--;

                    fseek(binFile, offset, SEEK_SET);
                    char mark = '1';
                    fwrite(&mark, sizeof(char), 1, binFile);
                    fwrite(&header.topo, sizeof(int), 1, binFile);
                    header.topo = rrnAtual;

                    for (int idx = 0; idx < qtdIndex; idx++) {
                        if (indexList[idx].codEstacao == data.codEstacao) {
                            for (int k = idx; k < qtdIndex - 1; k++) {
                                indexList[k] = indexList[k + 1];
                            }
                            qtdIndex--;
                            break;
                        }
                    }
                }
                
                if (data.nomeEstacao != NULL) free(data.nomeEstacao);
                if (data.nomeLinha != NULL) free(data.nomeLinha);
            }
        }
    }

    // Flush do cabeçalho COMPLETO
    header.status = '1';
    fseek(binFile, 0, SEEK_SET);
    fwrite(&header.status, sizeof(char), 1, binFile);
    fwrite(&header.topo, sizeof(int), 1, binFile);
    fwrite(&header.proxRRN, sizeof(int), 1, binFile);
    fwrite(&header.nroEstacoes, sizeof(int), 1, binFile);
    fwrite(&header.nroParesEstacao, sizeof(int), 1, binFile);
    fclose(binFile);

    indexFile = fopen(arquivoIndex, "wb");
    char indexStatusOut = '0';
    fwrite(&indexStatusOut, sizeof(char), 1, indexFile);
    for (int i = 0; i < qtdIndex; i++) {
        fwrite(&indexList[i].codEstacao, sizeof(int), 1, indexFile);
        fwrite(&indexList[i].RRN, sizeof(int), 1, indexFile);
    }
    indexStatusOut = '1';
    fseek(indexFile, 0, SEEK_SET);
    fwrite(&indexStatusOut, sizeof(char), 1, indexFile);
    fclose(indexFile);

    if (indexList != NULL) free(indexList);

    binarioNaTela(arquivoDados);
    binarioNaTela(arquivoIndex);
}